package testsuite1;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(features = "src/test/java/testsuite1",
glue = "testsuite1" , tags="@tag1" )
public class testrunner02 extends AbstractTestNGCucumberTests 
{
}
